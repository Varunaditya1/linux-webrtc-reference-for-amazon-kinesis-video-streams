# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

import json
import operator
import os
import shutil
import subprocess
import sys
from collections import OrderedDict, namedtuple
from pathlib import Path

# TODO: add jinja2 or some other template generator to docker and use this instead of big string
# variables
HTML_OUTPUT_PRE = """
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>psd3 - Complex Multi-level Donut Chart</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
    <script type="text/javascript" src="d3.min.js"></script>

    <script type="text/javascript" src="psd3.js"></script>
    <link rel="stylesheet" type="text/css" href="psd3.css" />
</head>

<body style="margin: 15px;">

    <div class="container">
        <div class="well">
            <h2><a href="../index.html">psd3</a> - Multi-level Donut Chart</h2>
            <ul>
                <li>Double click a section to drill down!</li>
                <li>Double click center section to drill back up!</li>
            </ul>
        </div>

        <div id="chartContainer" class="well"></div>
    </div>

    <script type="text/javascript">
        var sampleData ="""

HTML_OUTPUT_POST = """;

        function formatNumber(num) {
            return num.toString().replace(/\\B(?=(\\d{3})+(?!\\d))/g, ",");
        }
        var config = {
            containerId: "chartContainer",
            width: 800,
            height: 800,
            data: sampleData,
            heading: {
                text: "Size distribution in ELF file",
                pos: "top"
            },
            label: function(d) {
                return ((d.data.name.length  > 23) ? d.data.name.substr(0, 23-1) + '...' : d.data.name ) + ":" + formatNumber(d.data.size);
            },
            value: "size",
            inner: "drilldown",
            tooltip: function(d) {
                return "<div style='background-color: #4a4; color: black; padding: 15px; text-align: middle; border: dotted 1px black;'><strong>" + d.name + "</strong> uses " + formatNumber(d.size) + " bytes in " + d.type + ".</div>";
            },
            transition: "linear",
            transitionDuration: 500,
            donutRadius: 50,
            gradient: true,
            colors: d3.scale.category20(),
            labelColor: "black",
            stroke: "#eee",
            strokeWidth: 1,
            drilldownTransition: "linear",
            drilldownTransitionDuration: 0,
            highlightColor: "#c00"
        };

        var samplePie = new psd3.Pie(config);
    </script>

</body>

</html>
"""  # noqa

MAX_SYMBOLS_TO_DISPLAY = 50

LibPath = namedtuple("LibPath", "path internal")


def get_linked_libraries(mapfile):
    output_libs = []
    map_path = os.path.dirname(mapfile)
    with open(mapfile) as file_in:
        archives_started = False
        started_reading = False
        for line in file_in:
            if "Archive member included to satisfy" in line:
                archives_started = True
            elif archives_started and not started_reading and len(line) > 3:
                started_reading = True
            elif archives_started and started_reading and len(line) < 3:
                break
            if started_reading and not line.startswith("   ") and not line.startswith("\t"):
                # relevant line split at last .a to get library
                lib = line.rpartition(".a")[0]
                lib = lib + ".a"
                lib_file = Path(lib)
                if not lib_file.is_file():
                    # Try if its a relative path name
                    lib = map_path + "/" + lib
                    lib_file = Path(lib)
                if lib_file.is_file():
                    internal_lib = False
                    if os.path.abspath(lib).startswith(
                        os.path.abspath(map_path + "../../../") + os.sep
                    ):
                        internal_lib = True
                    new_lib = LibPath(path=lib, internal=internal_lib)
                    if new_lib not in output_libs:
                        output_libs.append(LibPath(path=lib, internal=internal_lib))
                else:
                    print("Did not find file " + lib)
    return output_libs


Symbol = namedtuple("Symbol", "name size type")


def convert_nm_type(nm_type):
    if nm_type.lower() == "b" or nm_type.lower() == "d":
        return "RAM"
    else:
        return "ROM"


def get_symbols_with_nm(elf):
    symbols = []
    output = subprocess.run(["nm", "--print-size", "-t", "d", elf], stdout=subprocess.PIPE)
    for line in output.stdout.decode("utf-8").splitlines():
        elements = line.split()
        if len(elements) > 3:
            symbols.append(
                Symbol(
                    name=elements[3],
                    size=int(elements[1]),
                    type=convert_nm_type(elements[2]) + "(" + (elements[2]).lower() + ")",
                )
            )
    return symbols


def demangle(name):
    output = subprocess.run(["c++filt", name], stdout=subprocess.PIPE)
    return output.stdout.decode("utf-8")


def get_memory(mapfile, elf, report):
    libs = get_linked_libraries(mapfile)
    # Add elf at the end so that all symbols not found in a lib are accounted to the original elf
    libs.append(LibPath(path=elf, internal=True))
    symbol_to_file = {}
    progress = 0
    for lib in libs:
        progress += 1
        print(str(progress) + "/" + str(len(libs)) + " get nm symbols of " + lib.path)
        for symbol in get_symbols_with_nm(lib.path):
            if symbol not in symbol_to_file:
                symbol_to_file[symbol] = lib

    lib_sum = {}
    lib_top_symbols = {}
    internal_sum = 0
    external_sum = 0
    for symbol in get_symbols_with_nm(elf):
        lib = symbol_to_file[symbol]
        if lib not in lib_sum:
            lib_sum[lib] = 0
            lib_top_symbols[lib] = []

        need_insert = True
        for index, value in enumerate(lib_top_symbols[lib]):
            if value.size < symbol.size:
                need_insert = False
                lib_top_symbols[lib].insert(index, symbol)
                lib_top_symbols[lib] = lib_top_symbols[lib][:MAX_SYMBOLS_TO_DISPLAY]
                break
            if index > MAX_SYMBOLS_TO_DISPLAY:
                need_insert = False
                break
        if need_insert:
            lib_top_symbols[lib].append(symbol)

        lib_sum[lib] = lib_sum[lib] + symbol.size
        if lib.internal:
            internal_sum = internal_sum + symbol.size
        else:
            external_sum = external_sum + symbol.size

    output_json = [
        {
            "name": "AwsIoTFleetWiseEdgeInternal",
            "type": "RAM/ROM",
            "size": internal_sum,
            "drilldown": [],
        }
    ]
    fwe_libs = output_json[-1]["drilldown"]
    output_json.append(
        {"name": "external", "type": "RAM/ROM", "size": external_sum, "drilldown": []}
    )
    external_libs = output_json[-1]["drilldown"]
    for lib in OrderedDict(sorted(lib_sum.items(), key=operator.itemgetter(1), reverse=True)):
        liblist = external_libs
        if lib.internal:
            liblist = fwe_libs
        liblist.append(
            {
                "name": lib.path.rpartition("/")[2],
                "type": "RAM/ROM",
                "size": lib_sum[lib],
                "drilldown": [],
            }
        )
        print("### " + lib.path + ": " + str(lib_sum[lib]))
        top_size = 0
        if len(lib_top_symbols[lib]) > 0:
            for s in lib_top_symbols[lib]:
                name = demangle(s.name).strip()
                liblist[-1]["drilldown"].append(
                    {"name": name, "type": s.type, "size": s.size, "drilldown": []}
                )
                top_size = top_size + s.size
                # print("        "+str(s.size)+": "+name)
        remaining = lib_sum[lib] - top_size
        if remaining > 0:
            liblist[-1]["drilldown"].append(
                {"name": "rest", "type": "RAM/ROM", "size": remaining, "drilldown": []}
            )
    with open(report, "w") as text_file:
        json_object = json.dumps(output_json, indent=4)
        text_file.write(HTML_OUTPUT_PRE + json_object + HTML_OUTPUT_POST)
    print(
        "\nOVERALL: symbols:"
        + str(internal_sum + external_sum)
        + " internal:"
        + str(internal_sum)
        + " external:"
        + str(external_sum)
    )
    return internal_sum, external_sum


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print(f"usage from the build folder: python3 {__file__} <MAP_FILE>  <EXE_FILE> <OUT_DIR>")
    else:
        destination = sys.argv[3] + "/"
        if not os.path.exists(destination):
            os.makedirs(destination)
        script_directoy = os.path.dirname(os.path.realpath(__file__))
        static_content = script_directoy + "/static/"
        src_files = os.listdir(static_content)
        for file_name in src_files:
            full_file_name = os.path.join(static_content, file_name)
            if os.path.isfile(full_file_name):
                shutil.copy(full_file_name, destination)

        get_memory(sys.argv[1], sys.argv[2], destination + "report.html")
